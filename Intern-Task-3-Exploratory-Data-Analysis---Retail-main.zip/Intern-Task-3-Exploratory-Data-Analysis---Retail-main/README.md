# Intern-Task-3-Exploratory-Data-Analysis---Retail

## Task Explanation
As a business manager, try to find out the weak areas where you can work to make more profit. Perform ‘Exploratory Data Analysis’ on dataset ‘SampleSuperstore’. What all business problems you can derive by exploring the data?
